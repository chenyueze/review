/*************************************************************************
	> File Name: global.h
	> Author: 
	> Mail: 
	> Created Time: 2020年06月04日 星期四 19时31分42秒
 ************************************************************************/

#ifndef _GLOBAL_H
#define _GLOBAL_H
extern char conf_ans[50];
#endif
