/*************************************************************************
	> File Name: heart_beat.h
	> Author: 
	> Mail: 
	> Created Time: 2020年06月13日 星期六 17时54分47秒
 ************************************************************************/

#ifndef _HEART_BEAT_H
#define _HEART_BEAT_H
void *heart_beat(void *arg);
#endif
