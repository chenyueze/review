/*************************************************************************
	> File Name: server_re_drew.h
	> Author: 
	> Mail: 
	> Created Time: 2020年06月22日 星期一 16时33分47秒
 ************************************************************************/

#ifndef _SERVER_RE_DREW_H
#define _SERVER_RE_DREW_H
void re_drew();
#endif
