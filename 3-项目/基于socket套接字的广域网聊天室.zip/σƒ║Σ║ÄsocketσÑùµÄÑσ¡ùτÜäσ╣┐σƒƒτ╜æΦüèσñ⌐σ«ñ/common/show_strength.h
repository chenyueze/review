/*************************************************************************
	> File Name: show_strength.h
	> Author: 
	> Mail: 
	> Created Time: 2020年06月30日 星期二 19时54分25秒
 ************************************************************************/

#ifndef _SHOW_STRENGTH_H
#define _SHOW_STRENGTH_H
void show_strength();
#endif
