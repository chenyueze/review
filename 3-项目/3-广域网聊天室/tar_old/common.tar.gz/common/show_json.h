/*************************************************************************
	> File Name: show_json.h
	> Author: 
	> Mail: 
	> Created Time: 2020年07月05日 星期日 19时39分23秒
 ************************************************************************/

#ifndef _SHOW_JSON_H
#define _SHOW_JSON_H
void show_json(char *string);
#endif
