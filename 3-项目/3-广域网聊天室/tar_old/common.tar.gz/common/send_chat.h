/*************************************************************************
	> File Name: send_chat.h
	> Author: 
	> Mail: 
	> Created Time: 2020年06月22日 星期一 14时27分48秒
 ************************************************************************/

#ifndef _SEND_CHAT_H
#define _SEND_CHAT_H
void send_chat();
#endif
