/*************************************************************************
	> File Name: server_exit.h
	> Author: 
	> Mail: 
	> Created Time: 2020年06月14日 星期日 00时35分45秒
 ************************************************************************/

#ifndef _SERVER_EXIT_H
#define _SERVER_EXIT_H
void server_exit(int signum);
#endif
