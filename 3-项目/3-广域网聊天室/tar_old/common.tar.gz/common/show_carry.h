/*************************************************************************
	> File Name: show_carry.h
	> Author: 
	> Mail: 
	> Created Time: 2020年07月04日 星期六 15时14分36秒
 ************************************************************************/

#ifndef _SHOW_CARRY_H
#define _SHOW_CARRY_H
void show_carry(char *name);
#endif
