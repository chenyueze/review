/*************************************************************************
	> File Name: show_data_stream.h
	> Author: 
	> Mail: 
	> Created Time: 2020年06月30日 星期二 19时21分01秒
 ************************************************************************/

#ifndef _SHOW_DATA_STREAM_H
#define _SHOW_DATA_STREAM_H
void show_data_stream(int type);
#endif
