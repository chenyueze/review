/*************************************************************************
	> File Name: client_recver.h
	> Author: 
	> Mail: 
	> Created Time: 2020年06月13日 星期六 23时47分03秒
 ************************************************************************/

#ifndef _CLIENT_RECVER_H
#define _CLIENT_RECVER_H
void *client_recver(void *arg);
#endif
