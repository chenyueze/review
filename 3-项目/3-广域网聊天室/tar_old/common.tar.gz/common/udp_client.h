/*************************************************************************
	> File Name: udp_client.h
	> Author: 
	> Mail: 
	> Created Time: 2020年06月04日 星期四 18时57分11秒
 ************************************************************************/

#ifndef _UDP_CLIENT_H
#define _UDP_CLIENT_H
int socket_udp();
#endif
